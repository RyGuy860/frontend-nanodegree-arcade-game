frontend-nanodegree-arcade-game
===============================

How to Run Game: Please click on index.html to load the game board in any internet browser.
How to Play: Player can be moved using up, down, left and right keys.
How to win :  Player must reach the water blocks without colliding with bugs.  If player collision is detected player dies and resets to starting position.
